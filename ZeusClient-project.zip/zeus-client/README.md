# Zeus Client ⚡  (Fabric 1.21.4)

Warna: putih + kuning listrik. Menu: **Right Shift**. ClickGui ramah layar sentuh.

## Build
Butuh JDK 21 + internet (download Minecraft/Fabric).

    gradle wrapper --gradle-version 8.11.1   # sekali saja (atau buka di IntelliJ, import Gradle)
    ./gradlew build

Hasil: `build/libs/zeus-client-1.0.0.jar` -> taruh di folder `mods` (butuh Fabric API 0.119.2+1.21.4).

## Catatan
- Fabric Loader 0.14.0 terlalu tua untuk MC 1.21.4; build memakai 0.16.10. `fabric.mod.json` mengizinkan loader `>=0.14.0 <0.21.0` (0.14.0 sampai 0.20.x).
- Mobile (Pojav/Zalith): buat tombol kontrol on-screen yang dipetakan ke Right Shift.
- Tombol menu bisa diganti di Options > Controls > Zeus Client.
- Setting tersimpan di `config/zeus-client.properties` (status ON/OFF sengaja tidak disimpan).
- Setiap module dibungkus try/catch dan auto-OFF kalau error 3x (anti crash).

## Build lewat GitHub Actions
Upload semua isi folder ini ke repo (termasuk folder `.github`). Workflow `build.yml` otomatis jalan
tiap push, lalu ambil jar di tab Actions > run terbaru > Artifacts > `ZeusClient-jar`.
Pakai `zeus-client-1.0.0.jar` (BUKAN yang `-sources`).
