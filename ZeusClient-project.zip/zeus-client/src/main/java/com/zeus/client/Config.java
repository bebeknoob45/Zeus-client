package com.zeus.client;

import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Menyimpan nilai setting (bukan status ON/OFF) ke config/zeus-client.properties. */
public final class Config {
    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("zeus-client.properties");
    }

    private static String key(Module m, Setting s) {
        return (m.name + "." + s.name).replace(" ", "");
    }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(f)) {
                p.load(in);
            }
            for (Module m : ZeusClient.modules.all) {
                for (Setting s : m.settings) {
                    String v = p.getProperty(key(m, s));
                    if (v == null) continue;
                    try {
                        if (s.isBool) s.setBool(Boolean.parseBoolean(v));
                        else s.setNum(Double.parseDouble(v));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        } catch (Throwable t) {
            ZeusClient.LOGGER.warn("[Zeus] failed to load config", t);
        }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            for (Module m : ZeusClient.modules.all) {
                for (Setting s : m.settings) {
                    p.setProperty(key(m, s), s.isBool ? String.valueOf(s.on()) : String.valueOf(s.get()));
                }
            }
            try (OutputStream out = Files.newOutputStream(file())) {
                p.store(out, "Zeus Client");
            }
        } catch (Throwable t) {
            ZeusClient.LOGGER.warn("[Zeus] failed to save config", t);
        }
    }
}
