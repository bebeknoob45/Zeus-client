package com.zeus.client;

import com.zeus.client.gui.ClickGui;
import com.zeus.client.gui.Hud;
import com.zeus.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZeusClient implements ClientModInitializer {
    public static final String NAME = "Zeus Client";
    public static final Logger LOGGER = LoggerFactory.getLogger("ZeusClient");

    public static ModuleManager modules;
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        Config.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zeus.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.zeus"));

        ClientTickEvents.START_CLIENT_TICK.register(client -> modules.preTick());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            try {
                while (openKey.wasPressed()) {
                    if (client.currentScreen == null && client.player != null) {
                        client.setScreen(new ClickGui());
                    }
                }
            } catch (Throwable t) {
                LOGGER.error("[Zeus] failed to open menu", t);
            }
            modules.tick();
        });

        WorldRenderEvents.LAST.register(modules::renderWorld);

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            try {
                Hud.render(ctx);
            } catch (Throwable t) {
                LOGGER.error("[Zeus] hud error", t);
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.save());

        LOGGER.info("[Zeus] {} loaded - press Right Shift to open the menu", NAME);
    }
}
