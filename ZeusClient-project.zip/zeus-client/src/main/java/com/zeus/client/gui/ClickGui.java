package com.zeus.client.gui;

import com.zeus.client.Config;
import com.zeus.client.ZeusClient;
import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * ClickGui ramah layar sentuh: tombol besar, tap = klik (di-trigger saat jari diangkat),
 * geser (drag) untuk scroll, tombol +/- untuk angka (tanpa slider), kolom search.
 */
public class ClickGui extends Screen {
    public static final int YELLOW = 0xFFFFD60A;
    public static final int DARK = 0xFF1B1B1B;
    public static final int WHITE = 0xFFFFFFFF;
    public static final int PANEL = 0xFFFBFBFB;
    public static final int ROWBG = 0xFFEFEFEF;
    public static final int SETBG = 0xFFF7F7F7;
    public static final int GREY = 0xFF6B6B6B;

    private static final String[] BOLT = {
            "....###.",
            "...###..",
            "..###...",
            ".#######",
            "...####.",
            "..###...",
            ".###....",
            "###.....",
            "##......"
    };

    private static final int ROW = 26, SROW = 24, GAP = 3;

    private record Hit(int x, int y, int w, int h, boolean list, Runnable act) {
        boolean in(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private static Category tab = Category.COMBAT;
    private static String query = "";
    private static final Set<Module> open = new HashSet<>();

    private TextFieldWidget search;
    private final List<Hit> hits = new ArrayList<>();
    private int px, pw, listTop, listBottom;
    private double scroll, contentH;
    private double pressX, pressY;
    private boolean pressing, moved;
    private Hit pressedHit;
    private final long openedAt = System.currentTimeMillis();

    public ClickGui() {
        super(Text.literal("Zeus Client"));
    }

    public static void bolt(DrawContext ctx, int x, int y, int s, int color) {
        for (int r = 0; r < BOLT.length; r++) {
            for (int c = 0; c < BOLT[r].length(); c++) {
                if (BOLT[r].charAt(c) == '#') {
                    ctx.fill(x + c * s, y + r * s, x + (c + 1) * s, y + (r + 1) * s, color);
                }
            }
        }
    }

    @Override
    protected void init() {
        pw = Math.min(width - 10, 340);
        px = (width - pw) / 2;
        listTop = 90;
        listBottom = height - 10;

        search = new TextFieldWidget(textRenderer, px + 6, 37, pw - 12, 20, Text.literal("Search"));
        search.setPlaceholder(Text.literal("Search module..."));
        search.setText(query);
        search.setChangedListener(s -> {
            query = s;
            scroll = 0;
        });
        addDrawableChild(search);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xA0000000);
    }

    private List<Module> visibleModules() {
        List<Module> out = new ArrayList<>();
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            out.addAll(ZeusClient.modules.in(tab));
        } else {
            for (Module m : ZeusClient.modules.all) {
                if (m.name.toLowerCase(Locale.ROOT).contains(q)) out.add(m);
            }
        }
        return out;
    }

    private void center(DrawContext ctx, String s, int x, int y, int w, int h, int color) {
        ctx.drawText(textRenderer, s, x + (w - textRenderer.getWidth(s)) / 2, y + (h - 8) / 2 + 1, color, false);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        hits.clear();

        // panel + border
        ctx.fill(px - 2, 4, px + pw + 2, height - 4, YELLOW);
        ctx.fill(px, 6, px + pw, height - 6, PANEL);

        // header
        ctx.fill(px, 6, px + pw, 32, YELLOW);
        bolt(ctx, px + 8, 10, 2, DARK);
        ctx.drawText(textRenderer, "ZEUS CLIENT", px + 30, 15, DARK, false);
        String hint = "Right Shift";
        ctx.drawText(textRenderer, hint, px + pw - textRenderer.getWidth(hint) - 8, 15, 0xFF5A4B00, false);

        // tabs
        Category[] cats = Category.values();
        int tw = (pw - 12) / cats.length;
        for (int i = 0; i < cats.length; i++) {
            Category c = cats[i];
            int tx = px + 6 + i * tw;
            boolean sel = c == tab && query.trim().isEmpty();
            ctx.fill(tx + 1, 62, tx + tw - 1, 86, sel ? YELLOW : ROWBG);
            center(ctx, c.label, tx + 1, 62, tw - 2, 24, DARK);
            hits.add(new Hit(tx, 62, tw, 24, false, () -> {
                tab = c;
                scroll = 0;
                if (search != null) search.setText("");
            }));
        }

        // list (scrollable)
        double maxScroll = Math.max(0, contentH - (listBottom - listTop));
        scroll = Math.max(0, Math.min(maxScroll, scroll));

        ctx.enableScissor(px, listTop, px + pw, listBottom);
        int cy = listTop - (int) scroll;
        int x = px + 6, w = pw - 12;
        List<Module> mods = visibleModules();

        if (mods.isEmpty()) {
            center(ctx, "No modules found", px, listTop + 10, pw, 12, GREY);
        }

        for (Module m : mods) {
            boolean vis = cy + ROW > listTop && cy < listBottom;
            boolean hasSet = !m.settings.isEmpty();
            boolean isOpen = open.contains(m);
            if (vis) {
                ctx.fill(x, cy, x + w, cy + ROW, m.isEnabled() ? YELLOW : ROWBG);
                ctx.drawText(textRenderer, m.name, x + 8, cy + 4, DARK, false);
                ctx.drawText(textRenderer, textRenderer.trimToWidth(m.desc, w - 52), x + 8, cy + 14,
                        m.isEnabled() ? 0xFF4A3F00 : GREY, false);
                if (hasSet) {
                    int gx = x + w - 28;
                    ctx.fill(gx, cy + 3, gx + 25, cy + ROW - 3, isOpen ? DARK : 0x22000000);
                    center(ctx, isOpen ? "-" : "+", gx, cy + 3, 25, ROW - 6, isOpen ? YELLOW : DARK);
                    hits.add(new Hit(gx - 4, cy, 32, ROW, true, () -> {
                        if (!open.remove(m)) open.add(m);
                    }));
                }
                hits.add(new Hit(x, cy, w, ROW, true, m::toggle));
            }
            cy += ROW + GAP;

            if (isOpen) {
                for (Setting s : m.settings) {
                    boolean sv = cy + SROW > listTop && cy < listBottom;
                    if (sv) {
                        int sx = x + 10, sw = w - 10;
                        ctx.fill(sx, cy, sx + sw, cy + SROW, SETBG);
                        ctx.fill(sx, cy, sx + 3, cy + SROW, YELLOW);
                        ctx.drawText(textRenderer, s.name, sx + 8, cy + 8, DARK, false);
                        if (s.isBool) {
                            int cw = 44, chx = sx + sw - cw - 6;
                            ctx.fill(chx, cy + 3, chx + cw, cy + SROW - 3, s.on() ? YELLOW : 0xFFD8D8D8);
                            center(ctx, s.on() ? "ON" : "OFF", chx, cy + 3, cw, SROW - 6, DARK);
                            hits.add(new Hit(sx, cy, sw, SROW, true, s::toggle));
                        } else {
                            int bw = 28, valW = 44;
                            int plusX = sx + sw - bw - 4;
                            int valX = plusX - valW;
                            int minusX = valX - bw;
                            ctx.fill(minusX, cy + 2, minusX + bw, cy + SROW - 2, YELLOW);
                            center(ctx, "-", minusX, cy + 2, bw, SROW - 4, DARK);
                            ctx.fill(plusX, cy + 2, plusX + bw, cy + SROW - 2, YELLOW);
                            center(ctx, "+", plusX, cy + 2, bw, SROW - 4, DARK);
                            center(ctx, s.display(), valX, cy + 2, valW, SROW - 4, DARK);
                            hits.add(new Hit(minusX, cy, bw, SROW, true, () -> s.inc(-1)));
                            hits.add(new Hit(plusX, cy, bw, SROW, true, () -> s.inc(1)));
                        }
                    }
                    cy += SROW + GAP;
                }
            }
        }
        contentH = (cy + (int) scroll) - listTop;
        ctx.disableScissor();

        // scrollbar
        double viewH = listBottom - listTop;
        if (contentH > viewH) {
            int barH = (int) Math.max(20, viewH * viewH / contentH);
            int barY = listTop + (int) ((viewH - barH) * (scroll / Math.max(1, contentH - viewH)));
            ctx.fill(px + pw - 4, barY, px + pw - 1, barY + barH, YELLOW);
        }

        search.render(ctx, mx, my, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        pressX = mx;
        pressY = my;
        moved = false;
        pressing = false;
        pressedHit = null;
        for (Hit h : hits) {
            if (!h.in(mx, my)) continue;
            if (!h.list) {
                h.act.run();
                return true;
            }
            if (my >= listTop && my <= listBottom) {
                pressedHit = h;
                break;
            }
        }
        pressing = my >= listTop && my <= listBottom && mx >= px && mx <= px + pw;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (pressing) {
            if (Math.abs(my - pressY) > 6 || Math.abs(mx - pressX) > 6) moved = true;
            if (moved) {
                scroll -= dy;
                double maxScroll = Math.max(0, contentH - (listBottom - listTop));
                scroll = Math.max(0, Math.min(maxScroll, scroll));
            }
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (pressing && !moved && pressedHit != null) {
            try {
                pressedHit.act.run();
            } catch (Throwable t) {
                ZeusClient.LOGGER.error("[Zeus] gui action error", t);
            }
        }
        pressing = false;
        pressedHit = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        double maxScroll = Math.max(0, contentH - (listBottom - listTop));
        scroll = Math.max(0, Math.min(maxScroll, scroll - vertical * 22));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT && !search.isFocused()
                && System.currentTimeMillis() - openedAt > 300) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
