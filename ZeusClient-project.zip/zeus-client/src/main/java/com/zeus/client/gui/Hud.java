package com.zeus.client.gui;

import com.zeus.client.ZeusClient;
import com.zeus.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class Hud {
    private Hud() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        TextRenderer tr = mc.textRenderer;

        // watermark
        String wm = "Zeus Client";
        int w = tr.getWidth(wm) + 22;
        ctx.fill(3, 3, 3 + w, 16, ClickGui.YELLOW);
        ClickGui.bolt(ctx, 6, 4, 1, 0xFF1B1B1B);
        ctx.drawText(tr, wm, 18, 6, 0xFF1B1B1B, false);

        // daftar module aktif
        List<Module> en = new ArrayList<>();
        for (Module m : ZeusClient.modules.all) if (m.isEnabled()) en.add(m);
        en.sort(Comparator.comparingInt((Module m) -> -tr.getWidth(m.name)));
        int sw = mc.getWindow().getScaledWidth();
        int y = 3;
        for (Module m : en) {
            int tw = tr.getWidth(m.name);
            ctx.fill(sw - tw - 8, y, sw - 2, y + 11, 0x90000000);
            ctx.fill(sw - 2, y, sw, y + 11, ClickGui.YELLOW);
            ctx.drawText(tr, m.name, sw - tw - 5, y + 2, ClickGui.YELLOW, false);
            y += 11;
        }

        ZeusClient.modules.renderHud(ctx);
    }
}
