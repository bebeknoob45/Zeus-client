package com.zeus.client.module;

public enum Category {
    COMBAT("Combat"),
    RENDER("Render"),
    MISC("Misc"),
    CLIENT("Client");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
