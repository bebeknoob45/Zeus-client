package com.zeus.client.module;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final String desc;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();

    private boolean enabled;
    int errors;

    protected Module(String name, String desc, Category category) {
        this.name = name;
        this.desc = desc;
        this.category = category;
    }

    protected Setting bool(String n, boolean def) {
        Setting s = Setting.bool(n, def);
        settings.add(s);
        return s;
    }

    protected Setting num(String n, double def, double min, double max, double step) {
        Setting s = Setting.num(n, def, min, max, step);
        settings.add(s);
        return s;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) errors = 0;
        try {
            if (value) onEnable(); else onDisable();
        } catch (Throwable t) {
            com.zeus.client.ZeusClient.LOGGER.error("[Zeus] {} toggle error", name, t);
        }
    }

    protected boolean inGame() {
        return mc.player != null && mc.world != null && mc.interactionManager != null;
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onPreTick() {}
    public void onTick() {}
    public void onLeaveWorld() {}
    public void onWorldRender(WorldRenderContext ctx) {}
    public void onHud(DrawContext ctx) {}
}
