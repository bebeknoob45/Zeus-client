package com.zeus.client.module;

import com.zeus.client.ZeusClient;
import com.zeus.client.module.impl.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public final class ModuleManager {
    public final List<Module> all = new ArrayList<>();

    public ModuleManager() {
        // Combat
        all.add(new AimAssist());
        all.add(new AnchorMacro());
        all.add(new AutoCrystal());
        all.add(new AutoTotem());
        all.add(new KillAura());
        all.add(new CrystalOptimizer());
        // Render
        all.add(new Fullbright());
        all.add(new Freecam());
        all.add(new PlayerEsp());
        all.add(new StorageEsp());
        // Misc
        all.add(new Flight());
        all.add(new AutoClicker());
        all.add(new AutoMine());
        all.add(new NoBreakDelay());
        all.add(new NoJumpDelay());
        all.add(new Sprint());
        // Client
        all.add(new FakeScoreboard());
    }

    public List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : all) if (m.category == c) out.add(m);
        return out;
    }

    /** Semua pemanggilan module dibungkus try/catch: satu module error tidak bikin game crash. */
    private void guard(Module m, Consumer<Module> action) {
        try {
            action.accept(m);
        } catch (Throwable t) {
            m.errors++;
            ZeusClient.LOGGER.error("[Zeus] error in {} ({}/3)", m.name, m.errors, t);
            if (m.errors >= 3) {
                m.setEnabled(false);
                ZeusClient.LOGGER.warn("[Zeus] {} auto-disabled after repeated errors", m.name);
            }
        }
    }

    private boolean ready() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player != null && mc.world != null;
    }

    public void preTick() {
        if (!ready()) return;
        for (Module m : all) if (m.isEnabled()) guard(m, Module::onPreTick);
    }

    public void tick() {
        if (!ready()) {
            for (Module m : all) if (m.isEnabled()) guard(m, Module::onLeaveWorld);
            return;
        }
        for (Module m : all) if (m.isEnabled()) guard(m, Module::onTick);
    }

    public void renderWorld(WorldRenderContext ctx) {
        if (!ready()) return;
        for (Module m : all) if (m.isEnabled()) guard(m, mod -> mod.onWorldRender(ctx));
    }

    public void renderHud(DrawContext ctx) {
        for (Module m : all) if (m.isEnabled()) guard(m, mod -> mod.onHud(ctx));
    }
}
