package com.zeus.client.module;

import java.util.Locale;

public class Setting {
    public final String name;
    public final boolean isBool;
    public final double min, max, step;
    private boolean b;
    private double v;

    private Setting(String name, boolean isBool, boolean b, double v, double min, double max, double step) {
        this.name = name;
        this.isBool = isBool;
        this.b = b;
        this.v = v;
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public static Setting bool(String name, boolean def) {
        return new Setting(name, true, def, 0, 0, 0, 0);
    }

    public static Setting num(String name, double def, double min, double max, double step) {
        return new Setting(name, false, false, def, min, max, step);
    }

    public boolean on() { return b; }
    public double get() { return v; }
    public int getInt() { return (int) Math.round(v); }

    public void toggle() { b = !b; }

    public void setBool(boolean value) { b = value; }

    public void setNum(double value) {
        v = Math.max(min, Math.min(max, Math.round(value * 1000.0) / 1000.0));
    }

    public void inc(int dir) {
        setNum(v + dir * step);
    }

    public String display() {
        if (step >= 1) return String.valueOf(Math.round(v));
        return String.format(Locale.ROOT, "%.1f", v);
    }
}
