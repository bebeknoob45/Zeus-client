package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import com.zeus.client.util.Util;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class AimAssist extends Module {
    private final Setting range = num("Range", 5, 2, 8, 0.5);
    private final Setting speed = num("Speed", 6, 1, 30, 1);
    private final Setting fov = num("FOV", 90, 10, 360, 10);
    private final Setting click = bool("Only Click", true);
    private final Setting players = bool("Players", true);
    private final Setting mobs = bool("Mobs", false);

    public AimAssist() {
        super("Aim Assist", "Smooth aim toward targets", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (!inGame() || mc.currentScreen != null) return;
        if (click.on() && !mc.options.attackKey.isPressed()) return;
        ClientPlayerEntity p = mc.player;

        Entity best = null;
        double bestDiff = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!Util.valid(e, players.on(), mobs.on())) continue;
            if (p.distanceTo(e) > range.get()) continue;
            float[] r = Util.rot(p.getEyePos(), e.getEyePos());
            double diff = Math.abs(MathHelper.wrapDegrees(r[0] - p.getYaw()));
            if (diff > fov.get() / 2.0) continue;
            if (diff < bestDiff) {
                bestDiff = diff;
                best = e;
            }
        }
        if (best == null) return;

        float[] r = Util.rot(p.getEyePos(), best.getEyePos());
        float s = (float) speed.get();
        float yd = MathHelper.clamp(MathHelper.wrapDegrees(r[0] - p.getYaw()), -s, s);
        float pd = MathHelper.clamp(r[1] - p.getPitch(), -s, s);
        p.setYaw(p.getYaw() + yd);
        p.setPitch(MathHelper.clamp(p.getPitch() + pd, -90f, 90f));
    }
}
