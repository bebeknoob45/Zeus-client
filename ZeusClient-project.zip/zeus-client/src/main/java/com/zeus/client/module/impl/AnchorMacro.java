package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import com.zeus.client.util.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public class AnchorMacro extends Module {
    private final Setting charges = num("Charges", 1, 1, 4, 1);
    private final Setting delay = num("Delay", 2, 0, 10, 1);
    private final Setting onClick = bool("Hold Right Click", true);
    private int timer;

    public AnchorMacro() {
        super("Anchor Macro", "Charge & explode respawn anchor", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (!inGame() || mc.currentScreen != null) return;
        if (timer > 0) {
            timer--;
            return;
        }
        if (onClick.on() && !mc.options.useKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        BlockState st = mc.world.getBlockState(hit.getBlockPos());
        if (!st.isOf(Blocks.RESPAWN_ANCHOR)) return;
        int c = st.get(RespawnAnchorBlock.CHARGES);

        if (c < charges.getInt()) {
            int g = Util.hotbar(Items.GLOWSTONE);
            if (g < 0) return;
            Util.select(g);
        } else {
            int s = Util.hotbar(Items.TOTEM_OF_UNDYING);
            if (s < 0) {
                for (int i = 0; i < 9; i++) {
                    if (!mc.player.getInventory().getStack(i).isOf(Items.GLOWSTONE)) {
                        s = i;
                        break;
                    }
                }
            }
            if (s < 0) return;
            Util.select(s);
        }
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);
        timer = delay.getInt();
    }
}
