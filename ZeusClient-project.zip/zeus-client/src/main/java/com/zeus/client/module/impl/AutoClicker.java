package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import com.zeus.client.util.Util;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.Random;

public class AutoClicker extends Module {
    private final Setting cps = num("CPS", 10, 1, 20, 1);
    private final Setting hold = bool("Only Hold", true);
    private final Random rnd = new Random();
    private long next;

    public AutoClicker() {
        super("AutoClicker", "Auto attack what you aim at", Category.MISC);
    }

    @Override
    public void onTick() {
        if (!inGame() || mc.currentScreen != null) return;
        if (hold.on() && !mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult ehr) || ehr.getType() != HitResult.Type.ENTITY) return;
        long now = System.currentTimeMillis();
        if (now < next) return;
        Entity e = ehr.getEntity();
        if (e == null || !e.isAlive() || !e.isAttackable()) return;
        Util.attack(e);
        double d = 1000.0 / cps.get();
        next = now + (long) (d * (0.85 + rnd.nextDouble() * 0.3));
    }
}
