package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import com.zeus.client.util.Util;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class AutoCrystal extends Module {
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting targetRange = num("Target Range", 8, 3, 12, 1);
    private final Setting delay = num("Delay", 2, 0, 10, 1);
    private final Setting minHealth = num("Min Health", 6, 0, 20, 1);
    private final Setting autoSwitch = bool("Auto Switch", true);
    private int timer;

    public AutoCrystal() {
        super("Auto Crystal", "Place & break end crystals", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (!inGame() || mc.currentScreen != null) return;
        ClientPlayerEntity p = mc.player;
        if (p.getHealth() + p.getAbsorptionAmount() <= minHealth.get()) return;
        if (timer > 0) {
            timer--;
            return;
        }

        PlayerEntity target = null;
        double td = Double.MAX_VALUE;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == p || !e.isAlive() || e.isSpectator()) continue;
            double d = p.distanceTo(e);
            if (d <= targetRange.get() && d < td) {
                td = d;
                target = e;
            }
        }
        if (target == null) return;

        // 1) hancurkan crystal dekat target
        EndCrystalEntity bestCrystal = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EndCrystalEntity c) || !c.isAlive()) continue;
            if (p.distanceTo(c) > range.get() || p.distanceTo(c) < 2.5) continue;
            double d = c.distanceTo(target);
            if (d <= 6.0 && d < bd) {
                bd = d;
                bestCrystal = c;
            }
        }
        if (bestCrystal != null) {
            Util.attack(bestCrystal);
            timer = delay.getInt();
            return;
        }

        // 2) taruh crystal baru
        Hand hand;
        if (p.getOffHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.OFF_HAND;
        } else if (p.getMainHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.MAIN_HAND;
        } else if (autoSwitch.on() && Util.hotbar(Items.END_CRYSTAL) >= 0) {
            Util.select(Util.hotbar(Items.END_CRYSTAL));
            hand = Hand.MAIN_HAND;
        } else {
            return;
        }

        BlockPos tp = target.getBlockPos();
        BlockPos bestBase = null;
        double bestScore = Double.MAX_VALUE;
        Vec3d eye = p.getEyePos();
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = -2; dy <= 0; dy++) {
                    BlockPos base = tp.add(dx, dy, dz);
                    if (!(mc.world.getBlockState(base).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(base).isOf(Blocks.BEDROCK)))
                        continue;
                    BlockPos a1 = base.up();
                    if (!mc.world.getBlockState(a1).isAir() || !mc.world.getBlockState(a1.up()).isAir()) continue;
                    Vec3d cpos = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
                    if (eye.distanceTo(cpos) > range.get()) continue;
                    if (p.getPos().distanceTo(cpos) < 3.0) continue;
                    Box space = new Box(a1.getX(), a1.getY(), a1.getZ(), a1.getX() + 1, a1.getY() + 2, a1.getZ() + 1);
                    if (!mc.world.getOtherEntities(null, space).isEmpty()) continue;
                    double score = cpos.distanceTo(target.getPos());
                    if (score < bestScore) {
                        bestScore = score;
                        bestBase = base;
                    }
                }
            }
        }
        if (bestBase == null) return;

        BlockHitResult hit = new BlockHitResult(
                new Vec3d(bestBase.getX() + 0.5, bestBase.getY() + 1.0, bestBase.getZ() + 0.5),
                Direction.UP, bestBase, false);
        mc.interactionManager.interactBlock(p, hand, hit);
        p.swingHand(hand);
        timer = delay.getInt();
    }
}
