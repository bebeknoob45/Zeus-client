package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;

public class AutoMine extends Module {
    public AutoMine() {
        super("AutoMine", "Hold the mine button for you", Category.MISC);
    }

    @Override
    public void onTick() {
        if (!inGame()) return;
        mc.options.attackKey.setPressed(mc.currentScreen == null);
    }

    @Override
    public void onDisable() {
        if (mc.options != null) mc.options.attackKey.setPressed(false);
    }
}
