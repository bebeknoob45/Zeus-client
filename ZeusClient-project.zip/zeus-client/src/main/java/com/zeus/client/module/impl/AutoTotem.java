package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final Setting delay = num("Delay", 1, 0, 10, 1);
    private final Setting health = num("Health Below", 20, 1, 20, 1);
    private int timer;

    public AutoTotem() {
        super("Auto Totem", "Keep a totem in offhand", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (!inGame()) return;
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;
        if (timer > 0) {
            timer--;
            return;
        }
        ClientPlayerEntity p = mc.player;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (p.getHealth() + p.getAbsorptionAmount() > health.get()) return;

        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? 36 + i : i;
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
                timer = delay.getInt();
                return;
            }
        }
    }
}
