package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.util.Util;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class CrystalOptimizer extends Module {
    private int cd;

    public CrystalOptimizer() {
        super("CrystalOptimizer", "Crystals vanish instantly on hit", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (!inGame() || mc.currentScreen != null) return;
        if (cd > 0) {
            cd--;
            return;
        }
        if (!mc.options.attackKey.isPressed()) return;
        if (mc.crosshairTarget instanceof EntityHitResult ehr
                && ehr.getType() == HitResult.Type.ENTITY
                && ehr.getEntity() instanceof EndCrystalEntity crystal
                && crystal.isAlive()) {
            Util.attack(crystal);
            crystal.discard();
            cd = 1;
        }
    }
}
