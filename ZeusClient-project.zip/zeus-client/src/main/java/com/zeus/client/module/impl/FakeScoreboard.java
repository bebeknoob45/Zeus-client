package com.zeus.client.module.impl;

import com.zeus.client.gui.ClickGui;
import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public class FakeScoreboard extends Module {
    private final Setting kills = num("Kills", 0, 0, 9999, 1);
    private final Setting deaths = num("Deaths", 0, 0, 9999, 1);
    private final Setting coins = num("Coins", 1000, 0, 999999, 100);

    public FakeScoreboard() {
        super("Fake Scoreboard", "Custom client-side scoreboard", Category.CLIENT);
    }

    @Override
    public void onHud(DrawContext ctx) {
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        String title = "ZEUS CLIENT";
        String[] lines = {
                "Player: " + mc.player.getName().getString(),
                "Kills: " + kills.getInt(),
                "Deaths: " + deaths.getInt(),
                "Coins: " + coins.getInt(),
                "zeus.client"
        };
        int w = tr.getWidth(title);
        for (String l : lines) w = Math.max(w, tr.getWidth(l));
        w += 12;
        int h = (lines.length + 1) * 10 + 8;
        int x = mc.getWindow().getScaledWidth() - w - 4;
        int y = mc.getWindow().getScaledHeight() / 2 - h / 2;
        ctx.fill(x, y, x + w, y + h, 0x90000000);
        ctx.fill(x, y, x + w, y + 12, ClickGui.YELLOW);
        ctx.drawText(tr, title, x + (w - tr.getWidth(title)) / 2, y + 2, 0xFF1B1B1B, false);
        int ly = y + 16;
        for (String l : lines) {
            ctx.drawText(tr, l, x + 6, ly, 0xFFFFFFFF, false);
            ly += 10;
        }
    }
}
