package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import net.minecraft.entity.player.PlayerAbilities;

public class Flight extends Module {
    private final Setting speed = num("Speed", 1.0, 0.1, 5.0, 0.1);

    public Flight() {
        super("Flight", "Fly like creative mode", Category.MISC);
    }

    @Override
    public void onTick() {
        if (!inGame()) return;
        PlayerAbilities a = mc.player.getAbilities();
        a.allowFlying = true;
        a.flying = true;
        a.setFlySpeed((float) (speed.get() * 0.05));
    }

    @Override
    public void onDisable() {
        if (!inGame()) return;
        PlayerAbilities a = mc.player.getAbilities();
        a.setFlySpeed(0.05f);
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            a.allowFlying = false;
            a.flying = false;
        }
    }
}
