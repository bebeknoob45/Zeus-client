package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

public class Freecam extends Module {
    private final Setting speed = num("Speed", 1.0, 0.2, 5.0, 0.2);
    private OtherClientPlayerEntity cam;
    private double x, y, z;
    private int fwd, strafe, vert;

    public Freecam() {
        super("Freecam", "Fly the camera, body stays put", Category.RENDER);
    }

    private boolean down(KeyBinding kb) {
        if (mc.currentScreen != null) return false;
        InputUtil.Key k = KeyBindingHelper.getBoundKeyOf(kb);
        if (k.getCategory() != InputUtil.Type.KEYSYM) return false;
        return InputUtil.isKeyPressed(mc.getWindow().getHandle(), k.getCode());
    }

    private void start() {
        if (!inGame()) return;
        cam = new OtherClientPlayerEntity(mc.world, mc.player.getGameProfile());
        cam.copyPositionAndRotation(mc.player);
        x = mc.player.getX();
        y = mc.player.getY();
        z = mc.player.getZ();
        mc.setCameraEntity(cam);
    }

    private void stop() {
        cam = null;
        if (mc.player != null) mc.setCameraEntity(mc.player);
    }

    @Override
    public void onEnable() {
        start();
    }

    @Override
    public void onDisable() {
        stop();
        KeyBinding.updatePressedStates();
    }

    @Override
    public void onLeaveWorld() {
        cam = null;
    }

    @Override
    public void onPreTick() {
        if (cam == null || !inGame()) return;
        fwd = (down(mc.options.forwardKey) ? 1 : 0) - (down(mc.options.backKey) ? 1 : 0);
        strafe = (down(mc.options.leftKey) ? 1 : 0) - (down(mc.options.rightKey) ? 1 : 0);
        vert = (down(mc.options.jumpKey) ? 1 : 0) - (down(mc.options.sneakKey) ? 1 : 0);
        // tahan badan asli supaya tidak ikut bergerak
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sneakKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
    }

    @Override
    public void onTick() {
        if (!inGame()) return;
        if (cam == null) {
            start();
            return;
        }
        if (mc.getCameraEntity() != cam) mc.setCameraEntity(cam);

        float yaw = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        double rad = Math.toRadians(yaw);
        double s = speed.get() * 0.6;
        double sin = Math.sin(rad), cos = Math.cos(rad);
        x += (-sin * fwd + cos * strafe) * s;
        z += (cos * fwd + sin * strafe) * s;
        y += vert * s;
        cam.refreshPositionAndAngles(x, y, z, yaw, pitch);
    }
}
