package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class Fullbright extends Module {
    public Fullbright() {
        super("Fullbright", "See clearly in the dark", Category.RENDER);
    }

    @Override
    public void onTick() {
        if (!inGame()) return;
        StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400) {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 100000, 0, false, false, false));
        }
    }

    @Override
    public void onDisable() {
        if (inGame()) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }
}
