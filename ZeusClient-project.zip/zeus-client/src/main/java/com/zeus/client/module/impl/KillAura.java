package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import com.zeus.client.util.Util;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class KillAura extends Module {
    private final Setting range = num("Range", 4.2, 2, 6, 0.1);
    private final Setting players = bool("Players", true);
    private final Setting mobs = bool("Mobs", false);
    private final Setting rotate = bool("Rotate", false);
    private final Setting cooldown = bool("Cooldown", true);
    private int timer;

    public KillAura() {
        super("Kill Aura", "Auto attack nearby targets", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (!inGame() || mc.currentScreen != null) return;
        ClientPlayerEntity p = mc.player;

        Entity best = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!Util.valid(e, players.on(), mobs.on())) continue;
            double d = p.distanceTo(e);
            if (d <= range.get() && d < bd) {
                bd = d;
                best = e;
            }
        }
        if (best == null) return;

        if (rotate.on()) {
            float[] r = Util.rot(p.getEyePos(), best.getEyePos());
            p.setYaw(r[0]);
            p.setPitch(MathHelper.clamp(r[1], -90f, 90f));
        }

        if (cooldown.on()) {
            if (p.getAttackCooldownProgress(0.5f) < 0.92f) return;
        } else {
            if (timer-- > 0) return;
            timer = 2;
        }
        Util.attack(best);
    }
}
