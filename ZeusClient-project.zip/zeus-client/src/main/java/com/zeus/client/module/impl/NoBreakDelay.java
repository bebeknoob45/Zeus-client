package com.zeus.client.module.impl;

import com.zeus.client.mixin.ClientPlayerInteractionManagerAccessor;
import com.zeus.client.module.Category;
import com.zeus.client.module.Module;

public class NoBreakDelay extends Module {
    public NoBreakDelay() {
        super("NoBreakDelay", "Remove block break cooldown", Category.MISC);
    }

    @Override
    public void onTick() {
        if (!inGame()) return;
        ((ClientPlayerInteractionManagerAccessor) mc.interactionManager).zeus$setBlockBreakingCooldown(0);
    }
}
