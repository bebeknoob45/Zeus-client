package com.zeus.client.module.impl;

import com.zeus.client.mixin.LivingEntityAccessor;
import com.zeus.client.module.Category;
import com.zeus.client.module.Module;

public class NoJumpDelay extends Module {
    public NoJumpDelay() {
        super("NoJumpDelay", "Remove jump cooldown", Category.MISC);
    }

    @Override
    public void onTick() {
        if (!inGame()) return;
        ((LivingEntityAccessor) mc.player).zeus$setJumpingCooldown(0);
    }
}
