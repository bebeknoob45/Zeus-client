package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import com.zeus.client.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class PlayerEsp extends Module {
    private final Setting self = bool("Show Self", false);

    public PlayerEsp() {
        super("PlayerESP", "Boxes around players", Category.RENDER);
    }

    @Override
    public void onWorldRender(WorldRenderContext ctx) {
        if (!inGame()) return;
        float td = mc.getRenderTickCounter().getTickDelta(false);
        List<RenderUtil.Entry> list = new ArrayList<>();
        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            if (!p.isAlive()) continue;
            if (p == mc.player && !self.on()) continue;
            Vec3d off = p.getLerpedPos(td).subtract(p.getPos());
            Box box = p.getBoundingBox().offset(off);
            if (p == mc.player) list.add(new RenderUtil.Entry(box, 1f, 1f, 1f));
            else list.add(new RenderUtil.Entry(box, 1f, 0.84f, 0.04f));
        }
        RenderUtil.draw(ctx, list);
    }
}
