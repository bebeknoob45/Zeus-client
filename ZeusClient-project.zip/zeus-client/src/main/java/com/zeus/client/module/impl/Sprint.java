package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Always sprint when moving forward", Category.MISC);
    }

    @Override
    public void onTick() {
        if (!inGame()) return;
        ClientPlayerEntity p = mc.player;
        if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision
                && !p.isUsingItem() && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
