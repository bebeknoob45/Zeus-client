package com.zeus.client.module.impl;

import com.zeus.client.module.Category;
import com.zeus.client.module.Module;
import com.zeus.client.module.Setting;
import com.zeus.client.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.List;

public class StorageEsp extends Module {
    private final Setting chests = bool("Chests", true);
    private final Setting ender = bool("Ender Chests", true);
    private final Setting barrels = bool("Barrels", true);
    private final Setting shulkers = bool("Shulkers", true);
    private volatile List<RenderUtil.Entry> cache = List.of();
    private int t;

    public StorageEsp() {
        super("StorageESP", "Boxes around containers", Category.RENDER);
    }

    @Override
    public void onDisable() {
        cache = List.of();
    }

    @Override
    public void onLeaveWorld() {
        cache = List.of();
    }

    @Override
    public void onTick() {
        if (!inGame()) return;
        if (t++ % 10 != 0) return;
        List<RenderUtil.Entry> list = new ArrayList<>();
        ChunkPos cp = mc.player.getChunkPos();
        int r = Math.min(mc.options.getViewDistance().getValue(), 8);
        for (int cx = cp.x - r; cx <= cp.x + r; cx++) {
            for (int cz = cp.z - r; cz <= cp.z + r; cz++) {
                Chunk c = mc.world.getChunk(cx, cz, ChunkStatus.FULL, false);
                if (c == null) continue;
                for (BlockEntity be : c.getBlockEntities().values()) {
                    if (be == null || be.isRemoved()) continue;
                    float[] col = null;
                    if (be instanceof EnderChestBlockEntity) {
                        if (ender.on()) col = new float[]{0.6f, 0.2f, 1f};
                    } else if (be instanceof ChestBlockEntity) {
                        if (chests.on()) col = new float[]{1f, 0.7f, 0.1f};
                    } else if (be instanceof BarrelBlockEntity) {
                        if (barrels.on()) col = new float[]{0.75f, 0.5f, 0.25f};
                    } else if (be instanceof ShulkerBoxBlockEntity) {
                        if (shulkers.on()) col = new float[]{1f, 0.4f, 0.8f};
                    }
                    if (col != null) {
                        list.add(new RenderUtil.Entry(new Box(be.getPos()).contract(0.06), col[0], col[1], col[2]));
                    }
                }
            }
        }
        cache = list;
    }

    @Override
    public void onWorldRender(WorldRenderContext ctx) {
        RenderUtil.draw(ctx, cache);
    }
}
