package com.zeus.client.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;

public final class RenderUtil {
    private RenderUtil() {}

    public record Entry(Box box, float r, float g, float b) {}

    /** Gambar outline box tembus tembok (dipakai ESP). */
    public static void draw(WorldRenderContext ctx, List<Entry> entries) {
        if (entries == null || entries.isEmpty()) return;
        if (ctx.matrixStack() == null || ctx.camera() == null) return;

        Matrix4f m = ctx.matrixStack().peek().getPositionMatrix();
        Vec3d cam = ctx.camera().getPos();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.lineWidth(2.0f);

        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (Entry e : entries) {
            box(bb, m, cam, e.box(), e.r(), e.g(), e.b(), 1f);
        }
        BufferRenderer.drawWithGlobalProgram(bb.end());

        RenderSystem.lineWidth(1.0f);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void box(BufferBuilder bb, Matrix4f m, Vec3d cam, Box b, float r, float g, float bl, float a) {
        float x1 = (float) (b.minX - cam.x), y1 = (float) (b.minY - cam.y), z1 = (float) (b.minZ - cam.z);
        float x2 = (float) (b.maxX - cam.x), y2 = (float) (b.maxY - cam.y), z2 = (float) (b.maxZ - cam.z);
        // bawah
        line(bb, m, x1, y1, z1, x2, y1, z1, r, g, bl, a);
        line(bb, m, x2, y1, z1, x2, y1, z2, r, g, bl, a);
        line(bb, m, x2, y1, z2, x1, y1, z2, r, g, bl, a);
        line(bb, m, x1, y1, z2, x1, y1, z1, r, g, bl, a);
        // atas
        line(bb, m, x1, y2, z1, x2, y2, z1, r, g, bl, a);
        line(bb, m, x2, y2, z1, x2, y2, z2, r, g, bl, a);
        line(bb, m, x2, y2, z2, x1, y2, z2, r, g, bl, a);
        line(bb, m, x1, y2, z2, x1, y2, z1, r, g, bl, a);
        // tiang
        line(bb, m, x1, y1, z1, x1, y2, z1, r, g, bl, a);
        line(bb, m, x2, y1, z1, x2, y2, z1, r, g, bl, a);
        line(bb, m, x2, y1, z2, x2, y2, z2, r, g, bl, a);
        line(bb, m, x1, y1, z2, x1, y2, z2, r, g, bl, a);
    }

    private static void line(BufferBuilder bb, Matrix4f m, float ax, float ay, float az, float bx, float by, float bz,
                             float r, float g, float b, float a) {
        bb.vertex(m, ax, ay, az).color(r, g, b, a);
        bb.vertex(m, bx, by, bz).color(r, g, b, a);
    }
}
