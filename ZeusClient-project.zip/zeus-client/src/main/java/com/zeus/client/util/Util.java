package com.zeus.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Util {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private Util() {}

    public static boolean valid(Entity e, boolean players, boolean mobs) {
        if (e == null || e == mc.player || !e.isAlive()) return false;
        if (!(e instanceof LivingEntity)) return false;
        if (e.isSpectator()) return false;
        if (e instanceof PlayerEntity) return players;
        if (e instanceof Monster) return mobs;
        return false;
    }

    public static float[] rot(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        return new float[]{yaw, MathHelper.clamp(pitch, -90f, 90f)};
    }

    public static int hotbar(Item item) {
        if (mc.player == null) return -1;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    public static void select(int slot) {
        if (mc.player != null && slot >= 0 && slot < 9) {
            mc.player.getInventory().selectedSlot = slot;
        }
    }

    public static void attack(Entity e) {
        if (mc.player == null || mc.interactionManager == null || e == null) return;
        mc.interactionManager.attackEntity(mc.player, e);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
